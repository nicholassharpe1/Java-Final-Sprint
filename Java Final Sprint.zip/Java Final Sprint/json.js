// FETCH and READ the people.json disk file

fetch('./people.json')
  .then(response => response.json())
  .then(data => {
    // Do something with the JSON data
    console.log(data); // Log the JSON data to the console

    // Access a specific value from the JSON data
    console.log(data[0].name);
    // Loop through an array in the JSON data
    data.forEach(person => {
      switch(person.instrument){
        case "guitar":
          console.log(`${person.name} plays the guitar.`);
          document.write(`${person.name} plays the guitar.`);
          break;
        case "piano":
          console.log(`${person.name} plays the piano.`);
          document.write(`${person.name} plays the piano.`);
          break;
        case "trumpet":
          console.log(`${person.name} plays the trumpet.`);
          document.write(`${person.name} plays the trumpet.`);
          break;
        case "clarinet":
          console.log(`${person.name} plays the clarinet.`);
          document.write(`${person.name} plays the clarinet.`);
          break;
        case "drums":
          console.log(`${person.name} plays the drums.`);
          document.write(`${person.name} plays the drums.`);
          break;
        case "saxophone":
          console.log(`${person.name} plays the saxophone.`);
          document.write(`${person.name} plays the saxophone.`);
          break;
      }  
          
      
      console.log(person); // Log each person in the array to the console
    });
  })
  .catch(error => {
    // Handle any errors that occur while fetching the file
    console.error(error);
  });
